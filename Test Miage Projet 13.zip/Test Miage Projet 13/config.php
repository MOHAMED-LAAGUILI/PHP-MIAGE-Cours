<?php
$cn=mysqli_connect('localhost','root','','miage') or die(mysqli_connect_error());