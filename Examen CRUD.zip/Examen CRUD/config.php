<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "miage";

$cn = mysqli_connect($host, $username,"", $database) or die(mysqli_connect_error());